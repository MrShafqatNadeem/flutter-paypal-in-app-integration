import 'package:flutter/material.dart';
import 'package:flutter_paypal_test/paypal_payments_screen.dart';

////   https://medium.com/flutter-community/paypal-payment-gateway-integration-in-flutter-379fbb3b87f5

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: PaypalPayment(
        onFinish: () {},
      ),
    );
  }
}

