package com.absol.flutter_paypal_test;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
